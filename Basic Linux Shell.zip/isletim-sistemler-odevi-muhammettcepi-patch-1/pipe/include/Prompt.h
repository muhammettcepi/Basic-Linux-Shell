#ifndef PROMPT_H
#define  PROMPT_H
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include <string.h>
#include<signal.h>
struct Prompt{
    pid_t   pid;
	void (*Prompt1p)(struct Prompt*);
	void (*Prompt2p)(struct Prompt*);
	char* (*getinputp)(struct Prompt*);
	void (*executep)(char comand[],struct Prompt*);
	void (*executewpidp)(char comand[],struct Prompt*,int background);
	int (*choosewhichp)(char comand[],struct Prompt*);
	int (*choosewhichpipeormultip)(char comand[],struct Prompt*);
	
	void (*Yoketprompt)(struct Prompt*);

};
typedef struct Prompt* Prompt;
Prompt PromptOLustur();
void Prompt1(const Prompt);
void Prompt2(const Prompt);
char * getinput(const Prompt);
void execute(char comand[],const Prompt);
void executewpid(char comand[],const Prompt prompt,int background);
int choosewhich(char comand[],const Prompt);
int choosewhichpipeormulti(char comand[],const Prompt);
void Destroyprompt(Prompt);

#endif