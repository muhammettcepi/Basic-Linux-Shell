#include<locale.h> 
#include "Pipe.h"
#include "Prompt.h"
#include<signal.h>



int main(){
 Prompt prompt=PromptOLustur();
	 signal(SIGINT, prompt->Prompt1p);
  signal(SIGALRM, prompt->Prompt2p);
  raise(SIGALRM);
prompt->Yoketprompt(prompt);
  while(1) ;	
return 0;
}