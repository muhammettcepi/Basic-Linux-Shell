#include "Pipe.h"
#include "Prompt.h"
#include "stdarg.h"

Prompt PromptOLustur(){
	Prompt this;
	this = (Prompt)malloc(sizeof(struct Prompt));
	this->Prompt1p=&Prompt1;
	this->Prompt2p=&Prompt2;
	this->getinputp=&getinput;
	this->executep=&execute;
	this->executewpidp=&executewpid;
	this->choosewhichp= &choosewhich;
	this->choosewhichpipeormultip= &choosewhichpipeormulti;
	this->Yoketprompt= &Destroyprompt;
}
char* getinput(const Prompt prompt){
        unsigned int len_max = 10;
        unsigned int current_size = 0;
        unsigned int j =0;
         char *pStr = malloc(len_max);
        current_size = len_max;
        if(pStr != NULL)
        {
	        int c = EOF;
	        
                //accept user input until hit enter or end of file
	        while (( c = getchar() ) != '\n' && c != EOF)
	        {
		        pStr[j++]=(char)c;

		        //if i reached maximize size then realloc size
		        if(j == current_size)
		        {
                                current_size = j+len_max;
			        pStr = realloc(pStr, current_size);
		        }
	        }
                	pStr[j] = '\0';
        }
	return pStr;
}
void executewpid(char comand[],const Prompt prompt,int background){
pid_t pid;
pid = fork();

  if(pid == 0) // Yavru proses, exec icra edilecek
    {
        char* islem1[4];
    char delim[]=" ";
		char *ptr1 = strtok(comand, delim);
		int countexec=0;
			while(ptr1 != NULL)
		{
			islem1[countexec]=ptr1;
			countexec++;
			ptr1 = strtok(NULL, delim);
		}
		islem1[countexec]=NULL;
		int esit=execvp(islem1[0],islem1);
        	if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
			free(islem1[j]);
        free(ptr1);

    } else if(pid > 0) // Ebeveyn shell olmaya devam edecek
    {
	  if (background){
      	wait(NULL);
		 	char* comand=getinput(prompt);
			choosewhich(comand,prompt);
		  printf("background task complete");
	  }
	  else
      Prompt1(prompt);
      fflush(stdout); 
      while(1) ;

    } else if(pid < 0) 
    {
      printf("Fork hatası!\n");

      exit(-1);
    }

}
void execute(char comand[],const Prompt prompt){
	
	char* islem1[4];
    char delim[]=" ";
		char *ptr1 = strtok(comand, delim);
		int countexec=0;
			while(ptr1 != NULL)
		{
			islem1[countexec]=ptr1;
			countexec++;
			ptr1 = strtok(NULL, delim);
		}
		islem1[countexec]=NULL;
		int esit=execvp(islem1[0],islem1);
        	if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
			free(islem1[j]);
        free(ptr1);
	
	
}
int choosewhichpipeormulti(char comand[] ,const Prompt prompt){
int inputlen=strlen(comand);
  for(int i=inputlen;i>0;i--){
	  if (comand[i]=='|'){
		Pipe1 p=PipeOLustur();
		p->manipulateinputpipe(comand,p);
		p->Yoketpipe(p);
	  	  Prompt1(prompt);
	  		return 0;
	  }
	  else if(comand[i]==')'||comand[i]==';'){
		  printf("coklu");
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='>'){
		  printf("giris yonlendirme");
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='<'){
		  printf("cikis yonlendirme");
		  Prompt1(prompt);
		  return 0;
	  }
}
	execute(comand,prompt);
	return 0;

}
int choosewhich(char comand[] ,const Prompt prompt){
int inputlen=strlen(comand);
  for(int i=inputlen;i>0;i--){
	  if (comand[i]=='|'){
		Pipe1 p=PipeOLustur();
		p->manipulateinputpipe(comand,p);
		p->Yoketpipe(p);
	  	  Prompt1(prompt);
	  		return 0;}
	  else if(comand[i]=='&'){
		  for(int i=inputlen;i>0;i--)
			  if(comand[i]=='&')
				  comand[i]='\0';
		  executewpid(comand,prompt,1);
		  return 0;
	  }
	  else if(comand[i]==')'||comand[i]==';'){
		  printf("coklu");
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='>'){
		  printf("giris yonlendirme");
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='<'){
		  printf("cikis yonlendirme");
		  Prompt1(prompt);
		  return 0;
	  }
}
	executewpid(comand,prompt,0);
	Prompt1(prompt);
	return 0;
}
void Prompt1(const Prompt prompt){
  printf("sacarsh > ");
  char* comand=getinput(prompt);
	choosewhich(comand,prompt);
	free(comand);
}
void Prompt2(const Prompt prompt){
	  printf("/nsacarsh > ");
  char* comand=getinput(prompt);
choosewhich(comand,prompt);
	free(comand);
}
void Destroyprompt(Prompt prompt){
if(prompt == NULL) return;
free(prompt);
prompt=NULL;
}