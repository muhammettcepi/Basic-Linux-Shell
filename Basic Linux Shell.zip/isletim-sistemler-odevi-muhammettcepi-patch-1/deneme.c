#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include<sys/wait.h> 
#include <regex.h> 

char* bakalim(char arr[]){
for(int i=0;i<strlen(arr);i++){
        if(arr[i]==' '){
                int m=i;
                        while(arr[m]==' '){
                        m++;
                        }
                if(arr[m]!='\0'&&m>i+1){
                        
                        int len=strlen(arr)-m+i+1;
                        char myarr[len];
                        for(int j=0;j<i+1;j++){
                        myarr[j]=arr[j];
                        }
                        int gap=m-i-1;
                        int counter=m;
                        int j=i+1;
                        for(j;j<len;j++){
                         arr[j]=arr[counter];
                                counter++;

                        }
                        for(j;j<strlen(arr);j++){
                                arr[j]='\0';
                        }
                        i=m;
                        //return bakalim(myarr);
                }
                else if(arr[m]=='\0'){
                       int len=i;
                       char myarr[len];
                        for(int j=0;j<i;j++){
                                myarr[j]=arr[j];
                        }
                        char *myarr1=myarr;
                        return myarr1;
                }
                else if(i==0){
                        int len=strlen(arr)-m;
                        char myarr[len];
                        int counter=m;
                        for(int j=0;j<len;j++){
                                arr[j]=arr[counter];
                                counter++;
                        }
                        //return bakalim(myarr);
                        }
                }
        }
        return arr;
}
pid_t   pid;

int** fd;
void exec1(char *);
void exec2(char *,int,int);
void execute1(char* ,char* [] ,char*,int );
/*void execute2(char*,int,int);
void exec3(char*,int,int);
void exec4(char*,int);*/
int main(int argc, char *argv[])
{
        char delim[] = "|";
	int ret;
        unsigned int len_max = 10;
        unsigned int current_size = 0;
        unsigned int j =0;
         char *pStr = malloc(len_max);
        current_size = len_max;
        if(pStr != NULL)
        {
	        int c = EOF;
	        
                //accept user input until hit enter or end of file
	        while (( c = getchar() ) != '\n' && c != EOF)
	        {
		        pStr[j++]=(char)c;

		        //if i reached maximize size then realloc size
		        if(j == current_size)
		        {
                                current_size = j+len_max;
			        pStr = realloc(pStr, current_size);
		        }
	        }
                	pStr[j] = '\0';
        }
        char comand[j];
        char comand1[j];
        strcpy(comand,pStr);
        strcpy(comand1,pStr);
        /*char comand[60];
        fgets(comand,60,stdin);*/
        int i=0;
        int count=0;
        char *ptr = strtok(comand, delim);
        char** islem;
       while( ptr != NULL ) {
                count++;
                ptr = strtok(NULL, delim);
       }
        islem=(char **)malloc(count * sizeof(char *));
        count=0;
        ptr= strtok(comand1, delim);
        while( ptr != NULL ) {
                islem[count]=ptr;
                count++;
                ptr = strtok(NULL, delim);
       }
        fd=(int **)malloc(count * sizeof(int *));
        for (int o=0; o<count; o++) 
         fd[o] = (int *)malloc(2 * sizeof(int)); 
        execute1(islem[0],islem,islem[count-1],count);
        free(pStr);
        pStr=NULL;
        free(fd);
        for(int o=0;o<count;o++)
                fd[o];
        free(islem);
        for(int o=0;o<count;o++)
                islem[o];
        free(ptr);
        
        return(0);
        }
void execute1(char* islem1,char* islem2[],char* islemson,int count){
if (pipe(fd[0]) == -1) {
                perror("bad pipe1");
                exit(1);
        }

        if ((pid = fork()) == -1) {
                perror("bad fork1");
                exit(1);
        } else if (pid == 0) {
                //count--;
                exec1(islem1);
                //execlp("echo", "echo", "13", NULL);
                //exec1("echo 13");
  //_exit(1);
        }
  // parent

  // fork (grep root)
        for (int j=1;j<count-1;j++){
               if (pipe(fd[j]) == -1) {
                perror("bad pipe1");
                exit(1);
        } 
        if ((pid = fork()) == -1) {
                perror("bad fork2");
                exit(1);
        } else if (pid == 0) {
    // pipe1 --> grep --> pipe2
                printf("%s",islem2[j]);
                exec2(islem2[j],1,j);
  // exec didn't work, exit
  //_exit(1);
        }
        }
        if ((pid = fork()) == -1) {
                perror("bad fork2");
                exit(1);
        } else if (pid == 0) {
    // pipe1 --> grep --> pipe2

                exec2(islemson,0,count-1);
  // exec didn't work, exit
  //_exit(1);
        }
  // parent

  // close unused fds

}
void exec1(char *islem) {
  // input from stdin (already done)
  // output to pipe1
         dup2(fd[0][1], 1);
  // close fds
         close(fd[0][0]);
         close(fd[0][1]);
  // exec
        char* islem1[4];
	int countexec=0;
        char delim[]=" ";
	char *ptr1 = strtok(islem, delim);
		while(ptr1 != NULL)
	{
		islem1[countexec]=ptr1;
		countexec++;
		ptr1 = strtok(NULL, delim);
	}
	islem1[countexec]=NULL;
	int esit=execvp(islem1[0],islem1);
        if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
	free(islem1[j]);
        free(ptr1);
        free(islem);
         //if(islem[0]=='.'){
                
                        //}
                //else
                        //system(islem);
exit(1);
  
}
void exec2(char *islem,int endorgo,int j) {
  // input from pipe1
        dup2(fd[j-1][0], 0);
        if(endorgo==1){

                dup2(fd[j][1], 1);
                // close fds
                close(fd[j][1]);
                close(fd[j][1]);
        }
        close(fd[j-1][0]);
        close(fd[j-1][1]);
                // exec
                // exec
        char* islem1[4];
        char delim[]=" ";
	char *ptr1 = strtok(islem, delim);
	int countexec=0;
		while(ptr1 != NULL)
	{
		islem1[countexec]=ptr1;
		countexec++;
		ptr1 = strtok(NULL, delim);
	}
	islem1[countexec]=NULL;
	int esit=execvp(islem1[0],islem1);
        if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
	free(islem1[j]);
        free(ptr1);
        free(islem);

exit(1);
}
