#ifndef PIPE_H
#define  PIPE_H
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include<sys/wait.h> 
#include <regex.h> 
struct Pipe1{
    pid_t   pid;
    int** fd;
	void (*execute1pipe)(char* islem1,char* islem2[],char* islemson,int count ,struct Pipe1*);
	int (*manipulateinputpipe)(char comand[],struct Pipe1*);
	void (*exec2pipe)(char *islem,int endorgo,int j,struct Pipe1*);
	void (*exec1pipe)(char *islem,struct Pipe1*);
	void (*Yoketpipe)(struct Pipe1*);
};
typedef struct Pipe1* Pipe1;
Pipe1 PipeOLustur();
int manipulateinput(char comand[],const Pipe1);
void execute1(char* islem1,char* islem2[],char* islemson,int count ,const Pipe1);
void exec1(char *islem,const Pipe1);
void exec2(char *islem,int endorgo,int j,const Pipe1);
void Destroy(Pipe1);

#endif