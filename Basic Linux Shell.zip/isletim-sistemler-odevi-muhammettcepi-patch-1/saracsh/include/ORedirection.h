#ifndef OREDIRECTION_H
#define  OREDIRECTION_H
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include<fcntl.h>
#include<sys/wait.h>
struct ORedirection{
	void (*outputRedirectionor)(char comand[],struct ORedirection*);	
	void (*inputRedirectonor)(char comand[],struct ORedirection*);
	void (*YoketORed)(struct PrompORedirectiont*);
};
typedef struct ORedirection* ORedirection;
ORedirection ORedirectionOLustur();
void outputRedirection(char comand[],const ORedirection);
void inputRedirection(char comand[],const ORedirection);
void DestroyOR(ORedirection);

#endif