#ifndef MULT_H
#define  MULTI_H
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include<fcntl.h>
#include<sys/wait.h>
struct Multi{
	void (*multiexecm)(char comand[],struct Multi*);	
	void (*Yoketmulti)(struct Multi*);
};
typedef struct Multi* Multi;
Multi MultiOlustur();
void multiexec(char comand[],const Multi);
void Destroymulti(Multi);

#endif