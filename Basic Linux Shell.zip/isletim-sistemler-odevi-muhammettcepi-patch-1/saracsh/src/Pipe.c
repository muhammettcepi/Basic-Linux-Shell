#include "Pipe.h"
#include "Prompt.h"
#include "stdarg.h"

Pipe1 PipeOLustur(){
	Pipe1 this;
	this = (Pipe1)malloc(sizeof(struct Pipe1));
	this->fd;
	this->pid;
	this->manipulateinputpipe=&manipulateinput;
	this->execute1pipe=&execute1;
	this->exec2pipe= &exec2;
	this->exec1pipe= &exec1;
	this->Yoketpipe= &Destroy;
}
int manipulateinput(char comand[],const Pipe1 pipe1){

        /*char comand[60];
        fgets(comand,60,stdin);*/
		int lenof=strlen(comand);
		char comand1[lenof];
		strcpy(comand1,comand);
	    char delim[]="|";
        int i=0;
        int count=0;
        char *ptr = strtok(comand, delim);
        char** islem;
       while( ptr != NULL ) {
                count++;
                ptr = strtok(NULL, delim);
       }
        islem=(char **)malloc(count * sizeof(char *));
        count=0;
        ptr= strtok(comand1, delim);
        while( ptr != NULL ) {
                islem[count]=ptr;
                count++;
                ptr = strtok(NULL, delim);
       }
        pipe1->fd=(int **)malloc(count * sizeof(int *));
        for (int o=0; o<count; o++) 
         pipe1->fd[o] = (int *)malloc(2 * sizeof(int)); 
        execute1(islem[0],islem,islem[count-1],count,pipe1);
        free(pipe1->fd);
        for(int o=0;o<count;o++)
                pipe1->fd[o];
        free(islem);
        for(int o=0;o<count;o++)
                islem[o];
        free(ptr);
	return 1;
}

void execute1(char* islem1,char* islem2[],char* islemson,int count ,const Pipe1 pipe1){
	if (pipe(pipe1->fd[0]) == -1) {
                perror("bad pipe1");
                exit(1);
        }

        if ((pipe1->pid = fork()) == -1) {
                perror("bad fork1");
                exit(1);
        } else if (pipe1->pid == 0) {
                //count--;
                exec1(islem1,pipe1);
                //execlp("echo", "echo", "13", NULL);
                //exec1("echo 13");
  //_exit(1);
        }
  // parent

  // fork (grep root)
        for (int j=1;j<count-1;j++){
               if (pipe(pipe1->fd[j]) == -1) {
                perror("bad pipe1");
                exit(1);
        } 
        if ((pipe1->pid = fork()) == -1) {
                perror("bad fork2");
                exit(1);
        } else if (pipe1->pid == 0) {
    // pipe1 --> grep --> pipe2
                exec2(islem2[j],1,j,pipe1);
  // exec didn't work, exit
  //_exit(1);
        }
        }
        if ((pipe1->pid = fork()) == -1) {
                perror("bad fork2");
                exit(1);
        } else if (pipe1->pid == 0) {
    // pipe1 --> grep --> pipe2

                exec2(islemson,0,count-1,pipe1);
  // exec didn't work, exit
  //_exit(1);
        }
}
void exec2(char *islem,int endorgo,int j,const Pipe1 pipe1){
	    dup2(pipe1->fd[j-1][0], 0);
        if(endorgo==1){

                dup2(pipe1->fd[j][1], 1);
                // close fds
                close(pipe1->fd[j][1]);
                close(pipe1->fd[j][1]);
        }
        close(pipe1->fd[j-1][0]);
        close(pipe1->fd[j-1][1]);
                // exec
                // exec
        Prompt prompt=PromptOLustur();
	int res=prompt->choosewhichpipeormultip(islem,prompt);
	wait(&res);
	prompt->Yoketprompt(prompt);
	free(islem);
}

void exec1(char *islem,const Pipe1 pipe1){
	// input from stdin (already done)
  // output to pipe1
         dup2(pipe1->fd[0][1], 1);
  // close fds
         close(pipe1->fd[0][0]);
         close(pipe1->fd[0][1]);
  // exec
              Prompt prompt=PromptOLustur();
	int res=prompt->choosewhichpipeormultip(islem,prompt);
	wait(&res);
	prompt->Yoketprompt(prompt);
        free(islem);
         //if(islem[0]=='.'){
                
                        //}
                //else
                        //system(islem);
  
}
void Destroy(Pipe1 pipe1){
if(pipe1 == NULL) return;
free(pipe1);
pipe1=NULL;
}