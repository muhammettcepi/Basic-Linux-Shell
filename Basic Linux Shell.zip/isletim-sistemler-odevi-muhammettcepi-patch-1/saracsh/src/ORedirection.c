#include "ORedirection.h"
#include "stdarg.h"
#include "Prompt.h"


ORedirection ORedirectionOLustur(){
	ORedirection this;
	this = (ORedirection)malloc(sizeof(struct ORedirection));
	this->outputRedirectionor=&outputRedirection;
	this->inputRedirectonor=&inputRedirection;
	this->YoketORed= &DestroyOR;
}

void outputRedirection(char comand[],const ORedirection Oredirection)
{
	char *komutlar[2];	
    char * anasatir = strdup(comand);
    int komutSayisi = 1;
    komutlar[komutSayisi -1]= strtok(anasatir, ">");
    while ( komutlar[komutSayisi]= strtok(NULL,">") ) 
	{
      komutSayisi++;
    }	
	char *path[2];
	int countexec = 1;
	path[countexec -1]= strtok(komutlar[1], " ");
	while ( path[countexec]= strtok(NULL," ") ) 
	{
		countexec++;
	} 
	path[countexec]=NULL;
	
	int st;
	int res;
	int pid;
	pid = fork();
	if(pid == 0) 
	{
		 int out= open(path[0],O_WRONLY | O_TRUNC | O_CREAT, S_IRUSR | S_IRGRP | S_IWGRP | S_IWUSR); 

			dup2(out, 1) ;  
			close(out);  
			Prompt prompt=PromptOLustur();
			prompt->choosewhichpipeormultip(komutlar[0],prompt);
			prompt->Yoketprompt(prompt);
        

	}else if(pid > 0) 
	{
	  wait(&st); 
	} else if(pid < 0) 
	{
	  printf("Fork hatası!\n");

	  exit(-1);
	}
	
	
}
void inputRedirection(char comand[],const ORedirection Oredirection){

char *komutlar[2];	
    char * anasatir = strdup(comand);
    int komutSayisi = 1;
    komutlar[komutSayisi -1]= strtok(anasatir, "<");
    while ( komutlar[komutSayisi]= strtok(NULL,"<") ) 
	{
      komutSayisi++;
    }	
	char *path[2];
	int countexec = 1;
	path[countexec -1]= strtok(komutlar[1], " ");
	while ( path[countexec]= strtok(NULL," ") ) 
	{
		countexec++;
	} 
	path[countexec]=NULL;
	
	int st;
	int res;
	int pid;
	pid = fork();
	if(pid == 0) 
	{
		 int in= open(path[0],O_RDONLY, 0); 
			dup2(in, STDIN_FILENO) ;  
		    close(in);
			Prompt prompt=PromptOLustur();
			prompt->choosewhichpipeormultip(komutlar[0],prompt);
			prompt->Yoketprompt(prompt);
        

	}else if(pid > 0) 
	{
	  wait(&st); 
	} else if(pid < 0) 
	{
	  printf("Fork hatası!\n");

	  exit(-1);
	}
	
	
}
void DestroyOR(ORedirection Oredirection){
if(Oredirection == NULL) return;
free(Oredirection);
Oredirection=NULL;
}