#include "Multi.h"
#include "stdarg.h"
#include "Prompt.h"

#define MAX 256

Multi MultiOlustur(){
	Multi this;
	this = (Multi)malloc(sizeof(struct Multi));
	this->multiexecm=&multiexec;
	this->Yoketmulti= &Destroymulti;
}


void multiexec(char comand[],const Multi Multi)
{        
    char **komutlar;
    int komutSayisi = 1;
	int lenof=strlen(comand);
		char anasatir[lenof];
		strcpy(anasatir,comand);
	int count=0;
	char *ptr = strtok(comand, ";");
       while( ptr != NULL ) {
                count++;
                ptr = strtok(NULL, ";");
       }
	komutlar=(char **)malloc(count * sizeof(char *));
	count=0;
	ptr= strtok(anasatir, ";");
    while ( ptr != NULL ) 
	{
     komutlar[count]=ptr;
              count++;;
		 ptr = strtok(NULL, ";");
    }
	/*
	for(int i =0 ; i<komutSayisi; i++)
	{
		printf("%d    %s \n",komutSayisi,komutlar[i]);
	}
	*/
		
	int k=0;
	while(k<count)
	{
		
		//char *komutlar2[strlen(komutlar[k])];
	    //char * anasatir1;
	//	printf("dondu no = %d \n " , k);
		int pid;
		int st;
		int res;
		
		pid = fork();
			if(pid == 0) 
			{
					
				//anasatir1 = strdup(komutlar[k]);
				
				 Prompt prompt=PromptOLustur();
				int res=prompt->choosewhichpipeormultip(komutlar[k],prompt);
				wait(&res);
				prompt->Yoketprompt(prompt);
			  
			  if(res < 0)
			  perror("EXEC HATASI: ");
			} else if(pid < 0) 
			{
			  perror("FORK HATASI: ");
			  exit(-1);
			}
			
			wait(NULL);
			
	    printf("\n");
			/*
			for(int j=0 ; j<1+countexec;j++)
			{
				free(komutlar2[j]);
			}*/
			
			
			//free(anasatir1);
			k++;
	}
	
}
void Destroymulti(Multi Multi){
if(Multi == NULL) return;
free(Multi);
Multi=NULL;
}
