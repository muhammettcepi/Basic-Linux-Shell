#include "Pipe.h"
#include "ORedirection.h"
#include "Prompt.h"
#include "stdarg.h"
#include "Multi.h"

int handler(int);
Prompt PromptOLustur(){
	Prompt this;
	this = (Prompt)malloc(sizeof(struct Prompt));
	this->Prompt1p=&Prompt1;
	this->Prompt2p=&Prompt2;
	this->getinputp=&getinput;
	this->executep=&execute;
	this->executewpidp=&executewpid;
	this->choosewhichp= &choosewhich;
	this->choosewhichpipeormultip= &choosewhichpipeormulti;
	this->Yoketprompt= &Destroyprompt;
}
char quit[]="quit";
void exit(int s){
exit(0);
}
int handler(int s){
int pid;
    int status;
    printf("[%d]retval: %d \n", pid, WEXITSTATUS(status));
	exit(-1);
	return 0;
}
void sig_chld(int signo) 
{
    int status, child_val,chid;
	chid = waitpid(-1, &status, WNOHANG);
	if (chid > 0)//Arkaplanda çalışmayan processler için bu değer -1 olacağından bu kontrol yapılmıştır.
	{
		if (WIFEXITED(status))	//Çocuk Normal Bir Şekilde mi Sonlandı ?
	    {
	        child_val = WEXITSTATUS(status); // Çocuğun durumu alındı.
	        printf("[%d] retval : %d \n",chid, child_val); //Çocuğun pid'i ve durumu ekrana yazdırılır.
	    }
	}
}
int saush_launchbg(char comand[],const Prompt prompt)
{
	pid_t pid;
	int status;

	struct sigaction act;
	act.sa_handler = sig_chld;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_NOCLDSTOP;
	if (sigaction(SIGCHLD,&act,NULL)<0)
	{
		fprintf(stderr,"sigaction failed\n");
		return 1;
	}

	pid=fork();
	if (pid == 0)
	{
		if (execute(comand,prompt) == -1)
		{
			printf("Command not found");
			kill(getpid(),SIGTERM);
		}
		//exit(EXIT_FAILURE);
	}
	else if (pid < 0)
	{
		perror("saush");
	}
	else
	{
		printf("Proses PID:%d Degeriyle Olusturuldu\n",pid);
	}
	return 1; 
}

char* getinput(const Prompt prompt){
        unsigned int len_max = 10;
        unsigned int current_size = 0;
        unsigned int j =0;
         char *pStr = malloc(len_max);
        current_size = len_max;
        if(pStr != NULL)
        {
	        int c = EOF;
	        
                //accept user input until hit enter or end of file
	        while (( c = getchar() ) != '\n' && c != EOF)
	        {
		        pStr[j++]=(char)c;

		        //if i reached maximize size then realloc size
		        if(j == current_size)
		        {
                                current_size = j+len_max;
			        pStr = realloc(pStr, current_size);
		        }
	        }
                	pStr[j] = '\0';
        }
	return pStr;
}
void executewpid(char comand[],const Prompt prompt,int background){
		/*struct sigaction act={0};
		act.sa_handler = handler;*/

pid_t pid;
pid = fork();
  if(pid == 0) // Yavru proses, exec icra edilecek
    {
	  /*if (background){
		   setpgid(pid, 0);
	  }*/
        char* islem1[4];
    char delim[]=" ";
		char *ptr1 = strtok(comand, delim);
		int countexec=0;
			while(ptr1 != NULL)
		{
			islem1[countexec]=ptr1;
			countexec++;
			ptr1 = strtok(NULL, delim);
		}
		islem1[countexec]=NULL;
		int esit=execvp(islem1[0],islem1);
        	if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
			free(islem1[j]);
        free(ptr1);

    } else if(pid > 0) // Ebeveyn shell olmaya devam edecek
    {
	  /*if (background){
		 sigaction(SIGCHLD, &act, NULL);  
		  Prompt1(prompt);
		 char* comand=getinput(prompt);
		choosewhich(comand,prompt);
		  printf("background task complete");
	  }
	  else*/
	Prompt1(prompt);
      fflush(stdout); 
      while(1) ;

    } else if(pid < 0) 
    {
      printf("Fork hatası!\n");

      exit(-1);
    }

}
int execute(char comand[],const Prompt prompt){
	
	char* islem1[4];
    char delim[]=" ";
		char *ptr1 = strtok(comand, delim);
		int countexec=0;
			while(ptr1 != NULL)
		{
			islem1[countexec]=ptr1;
			countexec++;
			ptr1 = strtok(NULL, delim);
		}
		islem1[countexec]=NULL;
		int esit=execvp(islem1[0],islem1);
        	if(esit < 0)
	                perror("Exec hatası: ");
        for(int j=0;j<countexec;j++)
			free(islem1[j]);
        free(ptr1);
	return esit;
	
}
int choosewhichpipeormulti(char comand[] ,const Prompt prompt){
int inputlen=strlen(comand);
  for(int i=inputlen;i>0;i--){
	  if (comand[i]=='|'){
		Pipe1 p=PipeOLustur();
		p->manipulateinputpipe(comand,p);
		p->Yoketpipe(p);
	  	  Prompt1(prompt);
	  		return 0;
	  }
	  else if(comand[i]==')'||comand[i]==';'){
		   Multi m=MultiOlustur();
		m->multiexecm(comand,m);
		m->Yoketmulti(m);
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='>'){
		  ORedirection OR=ORedirectionOLustur();
		OR->outputRedirectionor(comand,OR);
		OR->YoketORed(OR);
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='<'){
		ORedirection OR=ORedirectionOLustur();
		OR->inputRedirectonor(comand,OR);
		OR->YoketORed(OR);
		  Prompt1(prompt);
		  return 0;
	  }
}
	execute(comand,prompt);
	return 0;

}
int choosewhich(char comand[] ,const Prompt prompt){
int inputlen=strlen(comand);
  for(int i=inputlen;i>0;i--){
	  if (comand[i]=='|'){
		Pipe1 p=PipeOLustur();
		int res=p->manipulateinputpipe(comand,p);
		wait(&res);
		p->Yoketpipe(p);
	  	  Prompt1(prompt);
	  		return 0;
	  }
	  else if(comand[i]=='&'){
		  for(int i=inputlen;i>0;i--)
			  if(comand[i]=='&')
				  comand[i]='\0';
		  saush_launchbg(comand,prompt);
		  return 0;
	  }
	  else if(comand[i]==')'||comand[i]==';'){
		 Multi m=MultiOlustur();
		m->multiexecm(comand,m);
		m->Yoketmulti(m);
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='>'){
		 ORedirection OR=ORedirectionOLustur();
		OR->outputRedirectionor(comand,OR);
		OR->YoketORed(OR);
		  Prompt1(prompt);
		  return 0;
	  }
	  else if(comand[i]=='<'){
		   ORedirection OR=ORedirectionOLustur();
		OR->inputRedirectonor(comand,OR);
		OR->YoketORed(OR);
		  Prompt1(prompt);
		  return 0;
	  }
}
	executewpid(comand,prompt,0);
	Prompt1(prompt);
	return 0;
}
void Prompt1(const Prompt prompt){
  printf("sacarsh > ");
  char* comand=getinput(prompt);
	int comp= strcmp(comand,quit);
	if(comp==0){
	//wait(NULL);
		printf("cikiyor");
		free(comand);
		wait(NULL);
		raise(SIGKILL);
	}
	else{
		choosewhich(comand,prompt);
		
	}
	free(comand);
}
void Prompt2(const Prompt prompt){
	  printf("sacarsh > ");
  char* comand=getinput(prompt);
	int comp= strcmp(comand,quit);
	if(comp==0){
	//wait(NULL);
		printf("cikiyor");
		free(comand);
		wait(NULL);
		raise(SIGKILL);
	}
	else{
		choosewhich(comand,prompt);
		free(comand);
	}
	free(comand);
}

void Destroyprompt(Prompt prompt){
if(prompt == NULL) return;
free(prompt);
prompt=NULL;
}
